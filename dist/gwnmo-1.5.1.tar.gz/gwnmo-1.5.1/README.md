# Gradient Weighting by Neural Meta Optimizer
*Jan Miksa*

## TODO
- Rewrite using PyTorch Lightning